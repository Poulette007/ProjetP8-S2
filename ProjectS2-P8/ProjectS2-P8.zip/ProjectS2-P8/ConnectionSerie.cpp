#include "ConnectionSerie.h"

ConnectionSerie::ConnectionSerie()
{
	SP = new SerialPort(com.c_str(), BAUD);
    if (!SP->isConnected()) {
        cerr << "Impossible de se connecter au port " << string(com) <<  endl;
    }
}
ConnectionSerie::~ConnectionSerie()
{
	delete SP;
}
bool ConnectionSerie::Send(SerialPort* SP, json j_msg)
{
	// Return 0 if error
	string msg = j_msg.dump();
	bool ret = SP->writeSerialPort(msg.c_str(), msg.length());
	return ret;
}
bool ConnectionSerie::ReceiveRaw(SerialPort* SP, string& msg)
{
    // Return 0 if error
    // Message output in msg
    string str_buffer;
    char char_buffer[MSG_MAX_SIZE];
    int buffer_size;

    msg.clear(); // clear string


    // Version fonctionnelle dans VScode et Visual Studio
    buffer_size = SP->readSerialPort(char_buffer, MSG_MAX_SIZE);
    str_buffer.assign(char_buffer, buffer_size);
    msg.append(str_buffer);

    //msg.pop_back(); //remove '/n' from string

    return true;
}
int ConnectionSerie::getValue(const string index)
{
	json j_msg_rcv = getJson();
	if (j_msg_rcv != NULL) {
		return j_msg_rcv[index];
	}
    else
    {
        return -1;
    }
}
json ConnectionSerie::getJson()
{
    json j_msg_send, j_msg_rcv;
    j_msg_send["led"] = 1;
    if (!Send(SP, j_msg_send)) {
        cerr << "Erreur lors de l'envoie du message. " << endl;
    }
    // Reception message Arduino
    j_msg_rcv.clear(); // effacer le message precedent
    if (!ReceiveRaw(SP, raw_msg)) {
        cerr << "Erreur lors de la reception du message. " << endl;
    }

    // Impression du message de l'Arduino si valide
    if (raw_msg.size() > 0) {
        //cout << "raw_msg: " << raw_msg << endl;  // debug
        // Transfert du message en json
        j_msg_rcv = json::parse(raw_msg);
        cout << "Message de l'Arduino: " << j_msg_rcv << endl;
		return j_msg_rcv;
    }
    else
    {
		return NULL;
    }
}
bool ConnectionSerie::isConnected()
{
	return SP->isConnected();
}

void ConnectionSerie::closeSerial()
{
	SP->closeSerial();
}
