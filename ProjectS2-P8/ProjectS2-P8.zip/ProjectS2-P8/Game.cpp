#include "Game.h"
#include "Takeoff.h"	//a garder pour eviter inclusion circulaire
#include "Landing.h"	//a garder pour eviter inclusion circulaire

#define ACTOR_POS_X 1920
#define START_PLANE_X int(1920/3)


Game::Game(Stat* s)
{
	BackGroundVol = new QGraphicsPixmapItem();
	BackGroundVol->setPixmap(QPixmap("sprites/background/BackgroundVol").scaled(1920 + 10, 1080 + 50, Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
	gameScene->addItem(BackGroundVol);
	BackGroundVol->show();
	BackGroundVol->setPos(1920 / 3 - 10, -10);

	listActor = vector<Actor*>();
	plane = new Plane(START_PLANE_X, 1080/4);
	gameScene->addItem(plane);
	plane->setPos(0, 2 * 1080 / 4);
	plane->show();
	
	stat = s;
	isCollision = false;
	count = 0;
	landingCount = 200;
	msg_envoi["led"] = 1;
	promptText = new QGraphicsTextItem();
	promptText->setDefaultTextColor(Qt::yellow);
	promptText->setFont(QFont("Consolas", 24));
	promptText->setPos(100, 100);
	gameScene->addItem(promptText);
	takeoff = new Takeoff(this, plane, stat, promptText);
	
}

void Game::readKeyBoardGame()
{

	if (GetAsyncKeyState('W') < 0)
	{
		stat->readKeybord('W');
	}
	if (GetAsyncKeyState('S') < 0)
	{
		stat->readKeybord('S');
	}
	if (GetAsyncKeyState('A') < 0)
	{
		stat->readKeybord('A');
	}
	if (GetAsyncKeyState('D') < 0)
	{
		stat->readKeybord('D');
	}	
}
void Game::update()
{
	switch (state) {
	case Gamestate::Decollage:
		takeoff->updateTakeoff();
		break;
	case Gamestate::Gameplay:
		updateGameplay();
		break;
	case Gamestate::Landing:
		landing->updateLanding();
		break;
	case Gamestate::GameOver:
		break;
	}
}
void Game::updateGameplay()
{
	for (auto actor : listActor)
	{
		actor->setPos(actor->x() - (actor->getSpeed() * stat->getSpeed()), actor->y());

		if (actor->x() <= START_PLANE_X - actor->pixmap().width()) {
			gameScene->removeItem(actor); // Retirer l'acteur de la sc�ne Qt
			listActor.erase(std::remove(listActor.begin(), listActor.end(), actor), listActor.end());
			delete actor;
		}
	}
	stat->changeScore(250);
	stat->countFuel();
	plane->setPos(plane->x(), stat->getHeight());
	afficherStat();
	manageCollision();
	generateObstacles();
	if (true)
	{
		promptText->setPlainText("Atterrissage possible, appuyez sur Gauche, ou k, pout initialiser la sequence datterissage!");
		if (GetAsyncKeyState('K') < 0)
		{
			for (auto actor : listActor)
			{
				actor->setPos(actor->x() - (actor->getSpeed() * stat->getSpeed()), actor->y());
				gameScene->removeItem(actor); // Retirer l'acteur de la sc�ne Qt
				listActor.erase(std::remove(listActor.begin(), listActor.end(), actor), listActor.end());
				delete actor;
				
			}
			landing = new Landing(this, plane, stat, promptText);
			state = Gamestate::Landing;
		}
	}
	else
	{
		promptText->setPlainText("");
	}
	//Atterissage possible
	/*if (count >= possibleTouchDown && count <= (possibleTouchDown + 150))
	{
		gotoxy(30, 6);
		cout << "Atterissage possible, appuyez sur Gauche, ou k, pout initialiser la sequence datterissage!";
		if (_kbhit())
			ch = _getch();
		else if (ConnectionSerie::hasData())		//CA RUSH EN TABAROUETTE ICI, JE SAIS PAS PK
		{
			bpG = ConnectionSerie::getValue("BG");
			bpD = ConnectionSerie::getValue("BD");
			bpH = ConnectionSerie::getValue("BH");
			bpB = ConnectionSerie::getValue("BB");

		}
		if (ch == 'k' || bpG == 0 || bpB == 0 || bpH == 0 || bpD == 0)
		{
			stat->landing = true;
			stat->close = true;
		}
		if (count == possibleTouchDown + 150)
		{
			count = 0;
			possibleTouchDown += 150;
		}
	}
	count++;*/
}


void Game::manageCollision()
{
	for (int i = listActor.size() - 1; i >= 0; --i)
	{
		if (listActor[i]->x() <= plane->x() + plane->pixmap().width() && listActor[i]->y() == plane->y())
		{
			CollionDetected(listActor[i]);

			// Supprimer l'�l�ment de la sc�ne
			gameScene->removeItem(listActor[i]);

			// Lib�rer la m�moire
			delete listActor[i];

			// Supprimer l'�l�ment du tableau
			listActor.erase(listActor.begin() + i);
		}
	}
}
void Game::CollionDetected(Actor* actor)
{
	actor->action(*stat);
}
void Game::gotoxy(int x, int y)
{
		COORD coord = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), (coord));
}
void Game::afficherStat()
{
	// DEBUG
	gotoxy(0, 6);
	cout << "Gaz: " << stat->getFuel() << endl;
	cout << "Vitesse: " << stat->getSpeed() << endl;
	cout << "Pointage: " << stat->getScore() << endl;
	cout << "Hauteur: " << stat->getHeight() << endl;
	
	afficherStatManette();
	afficherStatOnGame();
	
}

void Game::afficherStatManette()
{
	//affiche gaz sur bargraph manette
	if (stat->getFuel() > 100)
	{
		msg_envoi["BAR"] = 10;
	}
	else if (stat->getFuel() > 90 && stat->getFuel() < 100)
	{
		msg_envoi["BAR"] = 9;
	}
	else if (stat->getFuel() > 80 && stat->getFuel() < 90)
	{
		msg_envoi["BAR"] = 8;
	}
	else if (stat->getFuel() > 70 && stat->getFuel() < 80)
	{
		msg_envoi["BAR"] = 7;
	}
	else if (stat->getFuel() > 60 && stat->getFuel() < 70)
	{
		msg_envoi["BAR"] = 6;
	}
	else if (stat->getFuel() > 50 && stat->getFuel() < 60)
	{
		msg_envoi["BAR"] = 5;
	}
	else if (stat->getFuel() > 40 && stat->getFuel() < 50)
	{
		msg_envoi["BAR"] = 4;
	}
	else if (stat->getFuel() > 30 && stat->getFuel() < 40)
	{
		msg_envoi["BAR"] = 3;
	}
	else if (stat->getFuel() > 20 && stat->getFuel() < 30)
	{
		msg_envoi["BAR"] = 2;
	}
	else if (stat->getFuel() > 10 && stat->getFuel() < 20)
	{
		msg_envoi["BAR"] = 1;
	}
	else if (stat->getFuel() < 10)
	{
		msg_envoi["BAR"] = 0;
	}
	msg_envoi["LCD"] = "score: " + std::to_string(stat->getScore());
	ConnectionSerie::Envoie(msg_envoi);
}

void Game::afficherStatOnGame()
{
	dash->update();
}

void Game::setupStatOnGame()
{
	dash = new QDashboard(stat);
	gameScene->addItem(dash);
	
}



#define TREE_SPAWN_MIN 45        // Minimum pour spawn un arbre
#define TREE_SPAWN_MAX 50        // Maximum pour spawn un arbre
#define WIND_SPAWN_MIN 1
#define WIND_SPAWN_MAX 4
#define GAS_SPAWN_MIN 10
#define GAS_SPAWN_MAX 13   
#define BIRD_SPAWN_MIN 20       
#define BIRD_SPAWN_MAX 25       
#define TREE_MIN_DIST 500       
#define OBSTACLE_MIN_DIST 700   
#define SCREEN_HEIGHT 1080      
#define RANGEE_HEIGHT (SCREEN_HEIGHT / 4) 

void Game::generateObstacles()
{
	int random = rand() % 2000;
	int posY = rand() % 3;
	bool tree = false;

	if (random >= TREE_SPAWN_MIN && random <= TREE_SPAWN_MAX)
	{
		for (auto actor : listActor)
		{
			if (actor->y() == 3) 
			{

				if (abs(actor->x() - ACTOR_POS_X) < TREE_MIN_DIST)
				{
					tree = true;
					break;
				}
			}
		}
		if (!tree) {
			listActor.push_back(new Tree(ACTOR_POS_X, 3 * RANGEE_HEIGHT)); // Spawne un arbre dans la derni�re rang�e
			gameScene->addItem(listActor.back());
		}
	}

	if (isPosYPossible(posY))
	{
		int yPos = posY * RANGEE_HEIGHT;

		if (random >= WIND_SPAWN_MIN && random <= WIND_SPAWN_MAX) {
			listActor.push_back(new Wind(ACTOR_POS_X, yPos));
			gameScene->addItem(listActor.back());
		}
		else if (random >= GAS_SPAWN_MIN && random <= GAS_SPAWN_MAX) {
			listActor.push_back(new Gaz(ACTOR_POS_X, yPos));
			gameScene->addItem(listActor.back());
		}
		else if (random >= BIRD_SPAWN_MIN && random <= BIRD_SPAWN_MAX) {
			listActor.push_back(new Bird(ACTOR_POS_X, yPos));
			gameScene->addItem(listActor.back());
		}
	}
}

bool Game::isPosYPossible(int y)
{
	for (auto actor : listActor)
	{
		if (actor->y() == y)
		{
			if (abs(actor->x() - ACTOR_POS_X) < OBSTACLE_MIN_DIST) 
				return false; 
		}
	}
	return true;
}

/*
void Game::generateObstacles()
{
	int random = rand() % 500;
	int posY = rand() % 3;
	bool tree = false;

	if (random >= 45 && random <= 50)
	{
		for (auto& actor : listActor)
		{
			if (actor->y() == 3)
			{
				if (actor->x() >= (ACTOR_POS_X - 3))
					tree = true;
			}
		}
		if (!tree) {
			listActor.push_back(new Tree(ACTOR_POS_X, 3 * 1080 / 4));
			gameScene->addItem(listActor.back());
		}
			
	}
	if (isPosYPossible(posY))
	{
		int(posY *= 1080 / 4);
		if (random >= 1 && random <= 2) {
			listActor.push_back(new Wind(ACTOR_POS_X, posY));
			gameScene->addItem(listActor.back());
		}
		else if (random >= 3 && random <= 4) {
			listActor.push_back(new Gaz(ACTOR_POS_X, posY));
			gameScene->addItem(listActor.back());
		}
		else if (random >= 11 && random <= 12) {
			listActor.push_back(new Bird(ACTOR_POS_X, posY));
			gameScene->addItem(listActor.back());
		}
	}
}
bool Game::isPosYPossible(int y)
{
	for (auto& actor : listActor)
	{
		if (actor->y() == y)
		{
			if (abs(actor->x() - ACTOR_POS_X) < 700)
				return false;
		}
	}
	return true;
}
bool Game::possibleLanding()
{
	qDebug() << "count:" << count;
	qDebug() << "landingCount:" << landingCount;
	if (plane->y() < 360 && count >= landingCount && count <= (landingCount + 150))
	{
		return true;
	}
	else if (count == landingCount + 150)
	{
		count = 0;
		landingCount += 150;
	}
	//petit mouvement initiale
	while (plane->getX() < START_PLANE_X)
	{
		bool hasD = ConnectionSerie::hasData();
		// --- Avec clavier ---	//
		if (_kbhit())
		{
			if (_getch() == 32)
			{
				// Effacer l'ancien avion
				gotoxy(plane->getX(), plane->getY());
				cout << "   ";
				speed++;
				stat->changeSpeed(speed);

				plane->setX(plane->getX() + 1);
				gotoxy(plane->getX(), plane->getY());
				cout << plane->getSprite();

				gotoxy(0, 8);
				cout << "Vitesse: " << speed << " / " << requiredSpeed;
			}
		}
		// --- Avec manette --- //
		else if (hasD == 1)
		{
			bool bpbas = ConnectionSerie::getValue("BB");
			if (!bpbas)
			{
				// Effacer l'ancien avion
				gotoxy(plane->getX(), plane->getY());
				cout << "   ";
				speed++;
				stat->changeSpeed(speed);

				plane->setX(plane->getX() + 1);
				gotoxy(plane->getX(), plane->getY());
				cout << plane->getSprite();

				gotoxy(0, 8);
				cout << "Vitesse: " << speed << " / " << requiredSpeed;
			
			}

		}
	}
	
	while (!vitesseGood || !hauteurGood)
	{
		//phase 1 : acceleration
		if (!vitesseGood)
		{
			count++;
			if (count % 2 == 0)
			{
				speed -= 1;
			}
			bool hasD = ConnectionSerie::hasData();
			if (_kbhit())
			{
				if (_getch() == 32)
				{
					speed += 10;
				}
			}
			else if (hasD == 1)
			{
				bool bpB = ConnectionSerie::getValue("BB");
				if (!bpB)
				{
					speed += 10;
				}
			}
			if (speed <= 1)
				speed = 1;
			else if (speed >= requiredSpeed)
			{
				speed = requiredSpeed;
				vitesseGood = true;
				stat->changeFuel(200 - (startindex * 2));
			}
		}

		//phase 2 : decollage
		if (vitesseGood == true && hauteurGood == false)
		{
			//melange les touches
			gotoxy(15, 3);
			//todo : faire que l'atterissage fonctionne avec le clavier et la manette
			//cout << "APPUYEZ SUR " << touches[0] << " ECHEC --> " << conteurEchecHauteur << "/4" << " REUSSITE --> " << conteurReussiteHauteur << "/4";
			//if (_kbhit())
			//{
			//	touche = _getch();
			//	if (touche == touches[0])
			//	{
			//		conteurReussiteHauteur++;
			//	}
			//	else if (touche != touches[0] && touche != 32)
			//	{
			//		conteurEchecHauteur++;
			//	}
			//	shuffle(touches.begin(), touches.end(), random_device());
			//}
			cout << "APPUYEZ SUR " << directions[0] << " ECHEC --> " << conteurEchecHauteur << "/4" << " REUSSITE --> " << conteurReussiteHauteur << "/4";
			if (ConnectionSerie::hasData())
			{
				bool bphaut = ConnectionSerie::getValue("BH");
				bool bpgauche = ConnectionSerie::getValue("BG");
				bool bpdroite = ConnectionSerie::getValue("BD");
				bool bpbas = ConnectionSerie::getValue("BB");
				if (directions[0] == "haut")
				{
					if (!bphaut)
					{
						conteurReussiteHauteur++;
					}
					else if (!bpgauche || !bpdroite || !bpbas)
					{
						conteurEchecHauteur++;
					}
				}
				else if (directions[0] == "gauche")
				{
					if (!bpgauche)
					{
						conteurReussiteHauteur++;
					}
					else if (!bphaut || !bpdroite || !bpbas)
					{
						conteurEchecHauteur++;
					}
				}
				else if (directions[0] == "droite")
				{
					if (!bpdroite)
					{
						conteurReussiteHauteur++;
					}
					else if (!bphaut || !bpgauche || !bpbas)
					{
						conteurEchecHauteur++;
					}
				}
				else if (directions[0] == "bas")
				{
					if (!bpbas)
					{
						conteurReussiteHauteur++;
					}
					else if (!bphaut || !bpgauche || !bpdroite)
					{
						conteurEchecHauteur++;
					}
				}
				Sleep(30);	//todo : a enlever quand on aura debouncer les boutons
				shuffle(directions.begin(), directions.end(), random_device());
			}
			if (conteurReussiteHauteur >= 4)
			{
				hauteurGood = true;
				plane->setX(3);
			}
			else if (conteurEchecHauteur >= 4)
			{
				system("cls");
				gotoxy(0, 9);
				cout << "L'avion s'est ecrase";
				//Sleep(5000);
				return false;
			}
		}


		//AFFICHAGE
		gotoxy(0, 8);
		cout << "Vitesse: " << speed << " / " << requiredSpeed;
		if (speed == requiredSpeed)
		{
			gotoxy(0, 8);
			cout << "Vitesse: " << speed << " / " << requiredSpeed << " - SPEED OK!!";
		}
		//pour le defilement de la piste
		if (startindex < length - ACTOR_POS_X)
		{
			startindex++;
		}
		//affichage de la portion visible de la piste
		gotoxy(0, 6);
		if (startindex + ACTOR_POS_X < length)
		{
			for (int i = 0; i < ACTOR_POS_X; i++)
			{
				if (i + startindex > length)
					cout << " ";
				else
					cout << piste[i + startindex];
			}
		}
		else //quand on arrive au bout de la piste
		{
			// Effacer l'ancien avion
			gotoxy(plane->getX(), plane->getY());
			cout << "   ";
			plane->setX(plane->getX() + 1);
			gotoxy(plane->getX(), plane->getY());
			cout << plane->getSprite();
			
		}

		int delay = max(20, 100 / speed);
		Sleep(delay);

		//condition d'echec
		if ((plane->getX() + startindex) >= length - 10)
		{
			system("cls");
			gotoxy(0, 9);
			cout << "L'avion s'est ecarse";
			stat->close;
			//sSleep(5000);

			return false;
		}
	}
}

bool Game::touchDown()
{
	int state = 0;
	int ch = 0;
	int speed = 100;
	int count = 0;
	int startindex = 0;
	plane->setX(2);
	plane->setY(0);
	int length = rand() % 200 + 400;
	bool atterrissageGood = false;
	vector<char> piste(length + 200);

	bool joyBas = false;
	bool bpG = true;
	bool bpB = true;
	bool bpD = true;
	bool bpH = true;
	//On remplit la foret
	for (int i = 0; i < 200; i++)
	{
		piste[i] = 'T';
	}

	//On remplit la piste
	for (int i = 200; i < length; i++)
	{
		if (i % 10 == 1)
			piste[i] = '|';
		else if (i >= length - 5)
			piste[i] = 'X';
		else
			piste[i] = '-';
	}
	
	//Jeu d'aterrissage
	while (!atterrissageGood)
	{
		switch (state)
		{
			case 0:	//Appuyer plusieurs fois sur a pour diminuer la vitesse
				gotoxy(0, 8);
				cout << "Diminuez la vitesse de 50% (bouton gauche sur manette, 'A' sur clavier)";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpG = ConnectionSerie::getValue("BG");
				}
				else
					break;
				if (ch == 'a' || bpG == 0)
				{
					speed -= 5;
					ch = 0;
					bpG = 1;
				}
				else
					break;
				if (speed <= 50)
				{
					state = 1;
					gotoxy(0, 8);
					cout << "Diminuez la vitesse de 50%: OK!";
					bpG = 1;
				}
				else
					break;
				break;
			case 1: //Diminuer la hauteur de l'avion
				gotoxy(0, 9);
				cout << "Diminuez la hauteur de 2 positions";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					joyBas = ConnectionSerie::getValue("JB");
				}
				if (ch == 's' || joyBas==1)
				{
					gotoxy(plane->getX(), plane->getY());
					cout << "      "; //Supprimer l'avion pour la deplacer
					plane->setY(plane->getY() + 1);
					ch = 0;
					joyBas = 0;
				}
				else
					break;
				if (plane->getY() == 2)
				{
					gotoxy(0, 9);
					cout << "Diminuez la hauteur de 2 positions: OK!";
					state = 2;
				}
				else
					break;
				break;
			case 2:
				gotoxy(0, 10);
				cout << "Sortez le train d'atterissage en appuiant sur: T, ou BAS sur manette";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpB = ConnectionSerie::getValue("BB");
				}
				if (ch == 't' || bpB ==0)
				{
					gotoxy(0, 10);
					cout << "Sortez le train d'atterissage en appuiant sur: T: OK!";
					state = 3;
					bpB = 1;
				}
				else
					break;
				break;
			case 3:
				gotoxy(0, 11);
				cout << "Diminuez la vitesse de 25%";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpG = ConnectionSerie::getValue("BG");
				}
				else
					break;
				if (ch == 'a' || bpG==0)
				{
					speed -= 2;
					ch = 0;
					bpG = 1;
				}
				else
					break;
				if (speed <= 25)
				{
					state = 4;
					gotoxy(0, 11);
					cout << "Diminuez la vitesse de 25%: OK!";
					bpG = 1;
				}
				else
					break;
				break;
			case 4:
				gotoxy(0, 12);
				cout << "Touchez le sol";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					joyBas = ConnectionSerie::getValue("JB");
				}
				if (ch == 's' || joyBas==1)
				{
					gotoxy(plane->getX(), plane->getY());
					cout << "      ";
					plane->setY(plane->getY() + 1);
					ch = 0;
					joyBas = 0;
				}
				else
					break;
				if (plane->getY() == 5)
				{
					gotoxy(0, 12);
					cout << "Touchez le sol: OK!";
					state = 5;
					joyBas = 0;
				}
				else
					break;
				break;
			case 5:
				gotoxy(0, 13);
				cout << "Diminuez la vitesse a 10%";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpG = ConnectionSerie::getValue("BG");
				}
				else
					break;
				if (ch == 'a' || bpG==0)
				{
					speed -= 2;
					ch = 0;
					bpG = 1;
				}
				else
					break;
				if (speed <= 10)
				{
					state = 6;
					gotoxy(0, 13);
					cout << "Diminuez la vitesse a 10%: OK!";
					bpG = 1;
				}
				else
					break;
				break;
			case 6:
				gotoxy(0, 14);
				cout << "Activez la propultion invese en appuiant sur: P, ou haut pour la manette";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpH = ConnectionSerie::getValue("BH");
				}
				if (ch == 'p' || bpH==0)
				{
					gotoxy(0, 14);
					cout << "Activez la propultion invese en appuiant sur: P: OK!";
					state = 7;
					bpH = 1;
				}
				else
					break;
				break;
			case 7:
				count++;
				if (count >= 10)
				{
					speed -= 1;
					if (speed == 1)
					{
						state = 8;
					}
					else
					{
						count = 0;
						break;
					}
				}
				else
					break;
			case 8:
				gotoxy(0, 15);
				cout << "Immobiliser l'avion avec les freins en appuiant sur: F, ou droit sur manette";
				if (_kbhit())
					ch = _getch();
				else if (ConnectionSerie::hasData())
				{
					bpD = ConnectionSerie::getValue("BD");
				}
				if (ch == 'f' || bpD == 0)
				{
					gotoxy(0, 10);
					cout << "Immobiliser l'avion avec les freins en appuiant sur: F: OK!";
					gotoxy(0, 7);
					cout << "Vitesse: 0    ";
					gotoxy(35, 3);
					cout << "Atterrissage reussi!!!";
					atterrissageGood = true;
					break;
				}
				else
					break;
				break;

			default:
				break;
		}
		//AFFICHAGE
		//pour le defilement de la piste
		if (startindex < length - ACTOR_POS_X)
		{
			startindex++;
		}
		//affichage de la portion visible de la piste
		gotoxy(0, 6);
		if (startindex + ACTOR_POS_X < length)
		{
			for (int i = 0; i < ACTOR_POS_X; i++)
			{
				if (i + startindex > length)
					cout << " ";
				else
					cout << piste[i + startindex];
			}
		}
		else //quand on arrive au bout de la piste
		{
			// Effacer l'ancien avion
			gotoxy(plane->getX(), plane->getY());
			cout << "   ";
			plane->setX(plane->getX() + 1);
			//Print l'avion
			gotoxy(plane->getX(), plane->getY());
			cout << plane->getSprite();
		}

		//Affichage de l'avion
		gotoxy(plane->getX(), plane->getY());
		cout << plane->getSprite();

		//Affichage de la vitesse
		gotoxy(0, 7);
		cout << "Vitesse: " << speed << "          " << "Pointage: " << stat->getScore() << "    ";
		
		//Vitesse du jeu
		int delay = max(20, 100 / speed);
		Sleep(delay);

		//Condition d'echec
		if ((plane->getX() + startindex) >= length - 10)
		{
			system("cls");
			gotoxy(35, 3);
			cout << "L'avion s'est ecraser";
			stat->close;
			return false;
		}
	}
	return true;
}
*/
